import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { AppState } from '../../redux/store';

const Home = () => {
    const count = useSelector((state: AppState) => state.common.count);
    return (
        <>
            <Link to="/">Go Back</Link>
            <div>Home Page</div>
            <div>Current Count: {count}</div>
        </>
    );
};
export default Home;
