import React from 'react';
import '@testing-library/jest-dom/extend-expect';

describe('Test for Index', () => {
    it('Should render App', () => {
        import('../index');
    });
});
