## React Starter Kit

Created using CRA with typescript
Redux thunk is used for global state management
Axios for API integration

## Start the Application
npm install - to install all the packages
npm start - to start the application
npm test - to run the test cases

## Version
React Version - 18.2.0